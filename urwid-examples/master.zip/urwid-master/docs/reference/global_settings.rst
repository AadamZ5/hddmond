Global Settings
===============

.. currentmodule:: urwid

.. autofunction:: set_encoding

.. autofunction:: get_encoding_mode

.. autofunction:: supports_unicode

